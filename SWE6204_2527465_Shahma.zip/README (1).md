# Telecom Customer Churn Prediction
## SWE6204 – Machine Learning | University of Bolton
### Assessment 1 Portfolio – Section 2 & 3

---

## Project Summary

This project develops a machine learning solution to predict customer churn for a telecommunications company. It was completed as part of a Data Scientist role scenario at HCL Technologies. The model identifies customers who are likely to leave the company so that the business can intervene proactively with targeted retention strategies.

---

## Dataset Details

| Property | Value |
|---|---|
| Dataset Name | Telco Customer Churn |
| Source | Kaggle – IBM Watson Analytics |
| Download URL | https://www.kaggle.com/datasets/blastchar/telco-customer-churn |
| File Name | WA_Fn-UseC_-Telco-Customer-Churn.csv |
| Total Rows | 7,043 |
| Total Columns | 21 features + 1 target |
| Target Variable | Churn (Yes = 1, No = 0) |
| Data Types | Numerical, Categorical, Binary (mixed) |

---

## How to Download the Dataset

1. Go to https://www.kaggle.com/datasets/blastchar/telco-customer-churn
2. Click the Download button
3. Extract the zip file
4. Place WA_Fn-UseC_-Telco-Customer-Churn.csv in the same folder as the notebook

---

## Folder Structure

```
Submission_Folder/
|
|-- SWE6204_Section2_Churn_Prediction.ipynb   <- Main Jupyter Notebook
|-- WA_Fn-UseC_-Telco-Customer-Churn.csv      <- Dataset file
|-- README.md                                 <- This file
```

---

## How to Run

### Step 1 - Install Requirements

```
pip install pandas numpy matplotlib seaborn scikit-learn
```

### Step 2 - Place Files Together
Make sure the notebook file and the CSV dataset are in the same folder.

### Step 3 - Open Jupyter Notebook
```
jupyter notebook
```
Navigate to the folder and open SWE6204_Section2_Churn_Prediction.ipynb

### Step 4 - Run All Cells
Click Kernel in the top menu then click Restart and Run All.
Wait approximately 1 to 2 minutes for all cells to finish.

---

## Notebook Sections

| Section | Description |
|---|---|
| Section 1 | Problem definition, library imports, dataset loading and inspection |
| Section 2.1 | Missing value detection and median imputation |
| Section 2.2 | Duplicate detection and removal |
| Section 2.3 | Outlier detection via IQR boxplots and Winsorisation capping |
| Section 2.4 | Label encoding, one-hot encoding, feature transformation |
| Section 3 | 80/20 stratified train/test split and StandardScaler feature scaling |
| Section 4 | Random Forest model training, Logistic Regression baseline, 5-fold cross-validation |
| Section 5 | Confusion matrix, accuracy, precision, recall, F1-score, ROC-AUC evaluation |
| Section 6 | Sample predictions table and probability distribution chart |
| Section 7 | Feature importance chart, final model summary, deployment decision |

---

## Model Details

| Property | Value |
|---|---|
| Primary Model | Random Forest Classifier |
| Number of Trees | 100 |
| Max Depth | 10 |
| Class Weight | Balanced |
| Baseline Model | Logistic Regression |
| Cross Validation | 5-Fold |

---

## Results

| Metric | Result |
|---|---|
| Test Accuracy | Above 70% threshold |
| ROC-AUC | Above 0.80 (Very Good) |
| Deployment Decision | Approved |

---

## Charts Generated

- Missing Value Heatmap
- Outlier Detection Boxplots
- Class Distribution in Train and Test Sets
- Confusion Matrix
- ROC Curve
- Model Performance Metrics Bar Chart
- Prediction Probability Distribution
- Top 15 Feature Importances

---

## References

- Geron, A. (2017) Hands-On Machine Learning with Scikit-Learn and TensorFlow. O'Reilly Media.
- Muller, A.C. and Guido, S. (2017) Introduction to Machine Learning with Python. O'Reilly Media.
- Harrington, P. (2012) Machine Learning in Action. Manning.
- Kotsiantis, S.B. (2007) Supervised machine learning: a review. Informatica, 31, pp. 249-268.
- IBM Watson Analytics (2023) Telco Customer Churn Dataset. https://www.kaggle.com/datasets/blastchar/telco-customer-churn
